import asyncio
import logging
from datetime import datetime, timedelta
from app.core.config import settings

from ...core.constants import DeviceStatus
from ...repositories import router_repository
from ...repositories.stats_repository import save_router_monitor_stats
from ...db.engine import get_session
from ...utils.cache import cache_manager, router_live_history
from ...infrastructure.devices.router_connector import router_connector

logger = logging.getLogger(__name__)

# Configurable timeout via environment variable (default: 30 seconds)
UNSUBSCRIBE_TIMEOUT = settings.MONITOR_UNSUBSCRIBE_TIMEOUT
CLEANUP_CHECK_INTERVAL = 10  # Check for expired routers every 10 seconds
# Interval for saving router stats to history (default: 5 minutes)
ROUTER_HISTORY_INTERVAL = settings.ROUTER_HISTORY_INTERVAL
# Configurable polling interval (default: 5 seconds) - how often to check routers
MONITOR_POLL_INTERVAL = settings.MONITOR_POLL_INTERVAL


class MonitorScheduler:
    """Scheduler centralizado: polling paralelo a routers con timeout de desconexión."""

    def __init__(self, poll_interval: float = 2.0):
        self._running = False
        self._subscribed_routers: dict[str, dict] = {}  # host -> {ref_count, last_unsubscribe_time}
        self.poll_interval = poll_interval
        self.UNSUBSCRIBE_TIMEOUT = UNSUBSCRIBE_TIMEOUT
        logger.info(
            f"[MonitorScheduler] Inicializado (Intervalo: {poll_interval}s, Timeout: {UNSUBSCRIBE_TIMEOUT}s)"
        )

    async def subscribe(self, host: str, creds: dict, wan_interface: str = None) -> None:
        """Suscribe un router. Si está marcado para limpieza, lo reactiva."""
        if host not in self._subscribed_routers:
            self._subscribed_routers[host] = {
                "ref_count": 0,
                "last_unsubscribe_time": None,
                "last_history_save": None,
                "backoff_until": None,
                "consecutive_failures": 0,
                "last_known_status": None,
                "wan_interface": wan_interface,
            }
        else:
            if wan_interface is not None:
                self._subscribed_routers[host]["wan_interface"] = wan_interface

        info = self._subscribed_routers[host]

        # Check backoff: si hubo error reciente, no intentar reconectar aún
        if info.get("backoff_until"):
            elapsed = (datetime.now() - info["backoff_until"]).total_seconds()
            if elapsed < 0:
                logger.warning(
                    f"[MonitorScheduler] Skipping subscribe to {host} - in backoff ({-elapsed:.0f}s remaining)"
                )
                raise Exception(f"Router {host} en período de espera por errores previos")

        was_zero = info["ref_count"] <= 0

        info["ref_count"] += 1
        info["last_unsubscribe_time"] = None  # Cancel any pending cleanup

        if was_zero:
            logger.info(
                f"[MonitorScheduler] Resubscribed to {host} (ref_count={info['ref_count']}) - pending cleanup cancelled"
            )

        try:
            await router_connector.subscribe(host, creds)
            # Conexión exitosa: resetear backoff
            info["consecutive_failures"] = 0
            info["backoff_until"] = None
            logger.info(f"[MonitorScheduler] Subscribed to {host} (ref_count={info['ref_count']})")
        except Exception as e:
            # Sanitize error message to hide passwords
            error_msg = str(e)
            if "password=" in error_msg:
                import re

                # Mask value in password=... pattern (case insensitive)
                error_msg = re.sub(
                    r'password=[^ \t\n\r\f\v]+"?', "password=******", error_msg, flags=re.IGNORECASE
                )

            logger.error(f"[MonitorScheduler] Failed to subscribe to {host}: {error_msg}")
            info["ref_count"] -= 1
            # Aplicar backoff exponencial (5s, 10s, 20s, 40s, max 60s)
            info["consecutive_failures"] = info.get("consecutive_failures", 0) + 1
            backoff_seconds = min(5 * (2 ** (info["consecutive_failures"] - 1)), 60)
            info["backoff_until"] = datetime.now() + timedelta(seconds=backoff_seconds)
            logger.warning(
                f"[MonitorScheduler] Backoff for {host}: {backoff_seconds}s (failures: {info['consecutive_failures']})"
            )

            if info["ref_count"] <= 0:
                del self._subscribed_routers[host]
            # Don't raise the raw exception with password either - raise a sanitized one or just the class
            raise Exception(error_msg)

    async def unsubscribe(self, host: str) -> None:
        """Desuscribe un router. Si ref_count=0, marca para limpieza con timeout."""
        if host not in self._subscribed_routers:
            return

        info = self._subscribed_routers[host]
        info["ref_count"] -= 1
        await router_connector.unsubscribe(host)

        if info["ref_count"] <= 0:
            info["last_unsubscribe_time"] = datetime.now()
            logger.info(
                f"[MonitorScheduler] Marked {host} for cleanup in {self.UNSUBSCRIBE_TIMEOUT}s (ref_count=0)"
            )
        else:
            logger.debug(
                f"[MonitorScheduler] Unsubscribed from {host} (ref_count={info['ref_count']})"
            )

    async def _cleanup_task(self):
        """Limpia routers inactivos después del timeout."""
        logger.info("[MonitorScheduler] Cleanup task started")

        while self._running:
            await asyncio.sleep(CLEANUP_CHECK_INTERVAL)

            current_time = datetime.now()
            hosts_to_cleanup = []

            for host, info in list(self._subscribed_routers.items()):
                if info["ref_count"] <= 0 and info.get("last_unsubscribe_time"):
                    elapsed = (current_time - info["last_unsubscribe_time"]).total_seconds()
                    if elapsed >= self.UNSUBSCRIBE_TIMEOUT:
                        hosts_to_cleanup.append(host)

            for host in hosts_to_cleanup:
                await self._do_cleanup(host)

        logger.info("[MonitorScheduler] Cleanup task stopped")

    async def _do_cleanup(self, host: str):
        """Limpia suscripciones, cache y credenciales de un router."""
        if host not in self._subscribed_routers:
            return

        info = self._subscribed_routers[host]
        if info["ref_count"] > 0:
            logger.debug(
                f"[MonitorScheduler] Skipping cleanup for {host} - ref_count is now {info['ref_count']}"
            )
            return

        del self._subscribed_routers[host]
        cache_manager.get_store("router_stats").delete(host)
        router_connector.cleanup_credentials(host)
        # Limpiar historial en vivo
        try:
            import asyncio
            asyncio.ensure_future(router_live_history.clear(host))
        except Exception:
            pass

        logger.info(f"[MonitorScheduler] Fully unsubscribed from {host} (timeout expired)")

    async def _update_db_status(self, host: str, status: str, result: dict = None):
        """Actualiza el estado del router en la base de datos."""
        try:
            async for session in get_session():
                await router_repository.update_router_status(session, host, status, result)
                # Session closes automatically due to generator? 
                # Actually get_session yields and assumes caller handles commit/close logic via 'yield' typically?
                # app/db/engine.py get_session typically yields session and closes in finally.
                # So we just break after one usage.
                break
                
            logger.debug(f"[MonitorScheduler] DB updated: {host} -> {status}")
        except Exception as e:
            logger.error(f"[MonitorScheduler] Failed to update DB for {host}: {e}")

    def reset_connection(self, host: str) -> dict:
        """
        Resetea el estado de conexión de un router (backoff, errores, etc.)
        sin eliminarlo ni perder su configuración.

        Útil para recuperar un router que entró en estado de error.

        Returns:
            dict con status y mensaje
        """
        # 1. Limpiar estado en el scheduler
        if host in self._subscribed_routers:
            info = self._subscribed_routers[host]
            info["backoff_until"] = None
            info["consecutive_failures"] = 0
            info["last_unsubscribe_time"] = None
            logger.info(f"[MonitorScheduler] Reset backoff state for {host}")

        # 2. Limpiar caché de stats
        try:
            stats_cache = cache_manager.get_store("router_stats")
            stats_cache.delete(host)
            logger.info(f"[MonitorScheduler] Cleared stats cache for {host}")
        except Exception as e:
            logger.warning(f"[MonitorScheduler] Could not clear cache for {host}: {e}")

        # 3. Limpiar pool de conexiones del router
        try:
            from ...infrastructure.devices.mikrotik import connection as mikrotik_conn

            mikrotik_conn.remove_pool(host)
            logger.info(f"[MonitorScheduler] Cleared connection pool for {host}")
        except Exception as e:
            logger.warning(f"[MonitorScheduler] Could not clear pool for {host}: {e}")

        # 4. Limpiar credenciales del connector (forzará re-autenticación)
        try:
            router_connector.cleanup_credentials(host)
            logger.info(f"[MonitorScheduler] Cleared credentials for {host}")
        except Exception as e:
            logger.warning(f"[MonitorScheduler] Could not clear credentials for {host}: {e}")

        return {
            "status": "success",
            "message": f"Estado de conexión reseteado para {host}. Listo para reconectar.",
        }

    async def refresh_host(self, host: str) -> dict:
        """
        Realiza un poll inmediato al router y actualiza DB + cache.
        Útil después de provisionar para mostrar 'Online' inmediatamente.
        """
        stats_cache = cache_manager.get_store("router_stats", default_ttl=5)

        try:
            result = await self._poll_host(host)
            if result:
                stats_cache.set(host, result)
                await self._update_db_status(host, DeviceStatus.ONLINE, result)
                return result
            else:
                await self._update_db_status(host, DeviceStatus.OFFLINE)
                return {"error": "No data returned"}
        except Exception as e:
            logger.error(f"[MonitorScheduler] refresh_host failed for {host}: {e}")
            await self._update_db_status(host, DeviceStatus.OFFLINE)
            return {"error": str(e)}

    async def run(self):
        """Loop principal Async."""
        self._running = True
        logger.info("[MonitorScheduler] Iniciando loop de polling...")
        cleanup_task = asyncio.create_task(self._cleanup_task())
        stats_cache = cache_manager.get_store("router_stats", default_ttl=5)

        try:
            while self._running:
                targets = list(self._subscribed_routers.items())

                if not targets:
                    await asyncio.sleep(1)
                    continue

                active_targets = [(host, info) for host, info in targets if info["ref_count"] > 0]

                if not active_targets:
                    await asyncio.sleep(1)
                    continue

                tasks = [self._poll_host(host) for host, _ in active_targets]
                results = await asyncio.gather(*tasks, return_exceptions=True)

                current_time = datetime.now()
                for (host, info), result in zip(active_targets, results):
                    if isinstance(result, Exception):
                        logger.error(f"[MonitorScheduler] Error polling {host}: {result}")
                        stats_cache.set(host, {"error": str(result)})
                        # Only write to DB if status changed
                        if info.get("last_known_status") != DeviceStatus.OFFLINE:
                            await self._update_db_status(host, DeviceStatus.OFFLINE)
                            info["last_known_status"] = DeviceStatus.OFFLINE
                            logger.info(f"[MonitorScheduler] Status changed: {host} -> OFFLINE")
                    elif result:
                        stats_cache.set(host, result)
                        # ── Historial en vivo ─────────────────────────────────
                        try:
                            free_mem = int(result.get("free_memory") or 0)
                            total_mem = int(result.get("total_memory") or 0)
                            ram_pct = (
                                round(((total_mem - free_mem) / total_mem) * 100)
                                if total_mem > 0
                                else 0
                            )
                            tx_bps = int(result.get("wan_tx_bps") or 0)
                            rx_bps = int(result.get("wan_rx_bps") or 0)
                            cpu = float(result.get("cpu_load") or 0)
                            await router_live_history.append(host, {
                                "cpu": cpu,
                                "ram": float(ram_pct),
                                "tx_kbps": round(tx_bps / 1024, 1),
                                "rx_kbps": round(rx_bps / 1024, 1),
                            })
                            logger.debug(f"[MonitorScheduler] live_history appended: {host} cpu={cpu} ram={ram_pct}")
                        except Exception as _lhe:
                            logger.warning(f"[MonitorScheduler] live_history FAILED for {host}: {_lhe}")
                        # ─────────────────────────────────────────────────────
                        # Only write to DB if status changed
                        if info.get("last_known_status") != DeviceStatus.ONLINE:
                            await self._update_db_status(host, DeviceStatus.ONLINE, result)
                            info["last_known_status"] = DeviceStatus.ONLINE
                            logger.info(f"[MonitorScheduler] Status changed: {host} -> ONLINE")

                        # Save to history if enough time has passed
                        last_save = info.get("last_history_save")
                        if (
                            last_save is None
                            or (current_time - last_save).total_seconds() >= ROUTER_HISTORY_INTERVAL
                        ):
                            try:
                                async for session in get_session():
                                    await save_router_monitor_stats(session, host, result)
                                    break
                                    
                                info["last_history_save"] = current_time
                                logger.debug(f"[MonitorScheduler] Saved history for {host}")
                            except Exception as e:
                                logger.error(
                                    f"[MonitorScheduler] Failed to save history for {host}: {e}"
                                )

                await asyncio.sleep(self.poll_interval)
        finally:
            self._running = False
            cleanup_task.cancel()
            try:
                await cleanup_task
            except asyncio.CancelledError:
                pass

        logger.info("[MonitorScheduler] Detenido.")

    async def _poll_host(self, host: str) -> dict:
        """Ejecuta la consulta al router en un thread separado."""
        info = self._subscribed_routers.get(host, {})
        wan_iface = info.get("wan_interface")
        return await asyncio.to_thread(
            router_connector.fetch_router_stats, host, None, wan_iface
        )


# Singleton - uses configurable poll interval from environment
monitor_scheduler = MonitorScheduler(poll_interval=MONITOR_POLL_INTERVAL)
