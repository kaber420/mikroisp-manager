class BaseRepository:
    pass
